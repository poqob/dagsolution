DAGSolution — Marka Kiti
===========================
Web: https://dagsolution.com
İletişim: mustafa@dagsolution.com

Bu paket DAGSolution marka varlıklarını içerir.

İçindekiler:
  svg/                    — Vektör logolar (SVG format)
  png/                    — PNG logolar (çeşitli boyutlarda)

Boyutlar:
  - 1024×1024  (Yüksek çözünürlük, store)
  - 512×512    (Sosyal medya, maskable icon)
  - 384×384    (PWA)
  - 192×192    (Web manifest)
  - 128×128    (Chrome Web Store)
  - 64×64      (Favicon)
  - 32×32      (Tab icon)

Renk Paleti:
  - Mavi (primary):    #3B82F6
  - Açık Mavi:         #60A5FA
  - Turuncu (accent):  #F97316
  - Gradient:          #60A5FA → #A78BFA

Tipografi:
  - Başlıklar & Body:  Inter (sans-serif)
  - Kod & Teknik:      JetBrains Mono (monospace)

Daha fazla bilgi: https://dagsolution.com/brand
